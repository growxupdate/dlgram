.. raw:: html

    <blockquote>
        <strong>Usable by</strong>
        <span class="usable-by"><i class="fa-solid fa-check" style="color: var(--color-green)"></i> Users</span>
        <span class="usable-by"><i class="fa-solid fa-check" style="color: var(--color-green)"></i> Bots</span>
    </blockquote>
