ReactionType
============

.. autoclass:: pyrogram.enums.ReactionType()
    :members:

.. raw:: html
    :file: ./cleanup.html
