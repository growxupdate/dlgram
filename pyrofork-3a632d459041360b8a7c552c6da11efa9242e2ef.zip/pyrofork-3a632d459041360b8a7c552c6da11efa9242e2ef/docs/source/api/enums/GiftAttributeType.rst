GiftAttributeType
==========

.. autoclass:: pyrogram.enums.GiftAttributeType()
    :members:

.. raw:: html
    :file: ./cleanup.html
