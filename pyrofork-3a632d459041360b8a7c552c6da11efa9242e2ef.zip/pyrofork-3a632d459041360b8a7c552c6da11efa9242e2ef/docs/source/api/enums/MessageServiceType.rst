MessageServiceType
==================

.. autoclass:: pyrogram.enums.MessageServiceType()
    :members:

.. raw:: html
    :file: ./cleanup.html