BusinessSchedule
==========

.. autoclass:: pyrogram.enums.BusinessSchedule()
    :members:

.. raw:: html
    :file: ./cleanup.html
