ChatType
========

.. autoclass:: pyrogram.enums.ChatType()
    :members:

.. raw:: html
    :file: ./cleanup.html