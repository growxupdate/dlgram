ChatMemberStatus
================

.. autoclass:: pyrogram.enums.ChatMemberStatus()
    :members:

.. raw:: html
    :file: ./cleanup.html