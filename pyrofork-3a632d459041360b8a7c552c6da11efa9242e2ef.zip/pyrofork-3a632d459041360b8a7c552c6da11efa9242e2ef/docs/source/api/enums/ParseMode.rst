ParseMode
=========

.. autoclass:: pyrogram.enums.ParseMode()
    :members:

.. raw:: html
    :file: ./cleanup.html