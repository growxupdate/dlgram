ClientPlatform
==========

.. autoclass:: pyrogram.enums.ClientPlatform()
    :members:

.. raw:: html
    :file: ./cleanup.html
