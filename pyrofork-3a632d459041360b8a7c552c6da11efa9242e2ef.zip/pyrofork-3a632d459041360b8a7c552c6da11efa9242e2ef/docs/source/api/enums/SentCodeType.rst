SentCodeType
============

.. autoclass:: pyrogram.enums.SentCodeType()
    :members:

.. raw:: html
    :file: ./cleanup.html