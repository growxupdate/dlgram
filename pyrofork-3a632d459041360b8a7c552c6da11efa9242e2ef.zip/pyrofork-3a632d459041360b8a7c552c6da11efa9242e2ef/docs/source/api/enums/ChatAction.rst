ChatAction
==========

.. autoclass:: pyrogram.enums.ChatAction()
    :members:

.. raw:: html
    :file: ./cleanup.html