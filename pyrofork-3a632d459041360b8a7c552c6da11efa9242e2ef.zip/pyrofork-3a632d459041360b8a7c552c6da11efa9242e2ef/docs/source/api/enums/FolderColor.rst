FolderColor
===========

.. autoclass:: pyrogram.enums.FolderColor()
    :members:

.. raw:: html
    :file: ./cleanup.html
