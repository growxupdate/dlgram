StoriesPrivacyRules
===================

.. autoclass:: pyrogram.enums.StoriesPrivacyRules()
    :members:

.. raw:: html
    :file: ./cleanup.html
